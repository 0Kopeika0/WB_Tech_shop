import pytest

from apps.products.models import Product


@pytest.fixture
def product(db):
    return Product.objects.create(
        name='Книга',
        description='Интересная',
        price='500.00',
        stock=10,
    )


@pytest.mark.django_db
class TestProductRead:
    """Чтение товаров — доступно всем."""

    def test_list_anonymous(self, api_client, product):
        response = api_client.get('/api/products/')
        assert response.status_code == 200
        assert len(response.data) == 1
        assert response.data[0]['name'] == 'Книга'

    def test_detail_anonymous(self, api_client, product):
        response = api_client.get(f'/api/products/{product.id}/')
        assert response.status_code == 200


@pytest.mark.django_db
class TestProductWrite:
    """Запись товаров — только админ."""

    url = '/api/products/'
    payload = {
        'name': 'Новый товар',
        'description': 'Описание',
        'price': '300.00',
        'stock': 5,
    }

    def test_create_anonymous_forbidden(self, api_client):
        response = api_client.post(self.url, self.payload, format='json')
        assert response.status_code == 401

    def test_create_user_forbidden(self, auth_client):
        """Обычный пользователь не может создавать."""
        response = auth_client.post(self.url, self.payload, format='json')
        assert response.status_code == 403

    def test_create_admin_success(self, admin_client):
        """Админ может создавать."""
        response = admin_client.post(self.url, self.payload, format='json')
        assert response.status_code == 201
        assert response.data['name'] == 'Новый товар'
        assert Product.objects.filter(name='Новый товар').exists()

    def test_update_user_forbidden(self, auth_client, product):
        response = auth_client.patch(
            f'/api/products/{product.id}/',
            {'price': '999.00'},
            format='json',
        )
        assert response.status_code == 403

    def test_update_admin_success(self, admin_client, product):
        response = admin_client.patch(
            f'/api/products/{product.id}/',
            {'price': '999.00'},
            format='json',
        )
        assert response.status_code == 200
        product.refresh_from_db()
        assert product.price == 999

    def test_delete_user_forbidden(self, auth_client, product):
        response = auth_client.delete(f'/api/products/{product.id}/')
        assert response.status_code == 403

    def test_delete_admin_success(self, admin_client, product):
        response = admin_client.delete(f'/api/products/{product.id}/')
        assert response.status_code == 204
        assert not Product.objects.filter(id=product.id).exists()
