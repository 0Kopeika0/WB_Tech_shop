from django.conf import settings
from django.db import models

from apps.products.models import Product


class CartItem(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='cart_items',
        verbose_name='Пользователь',
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='cart_items',
        verbose_name='Товар',
    )
    quantity = models.PositiveIntegerField(default=1, verbose_name='Количество')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Позиция корзины'
        verbose_name_plural = 'Корзина'
        unique_together = ('user', 'product')
        ordering = ('-created_at',)

    def __str__(self):
        return f'{self.user.username} — {self.product.name} x{self.quantity}'

    @property
    def total_price(self):
        return self.product.price * self.quantity
