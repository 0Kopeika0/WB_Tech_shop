class OrderError(Exception):
    """Ошибка бизнес-логики при создании заказа."""
    pass
