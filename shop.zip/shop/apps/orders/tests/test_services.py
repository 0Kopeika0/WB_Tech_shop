from decimal import Decimal

import pytest

from apps.cart.models import CartItem
from apps.orders.exceptions import OrderError
from apps.orders.models import Order, OrderItem
from apps.orders.services import create_order_from_cart
from apps.products.models import Product


@pytest.fixture
def product(db):
    return Product.objects.create(
        name='Книга',
        price='500.00',
        stock=10,
    )


@pytest.mark.django_db
class TestCreateOrderFromCart:
    """Тесты бизнес-логики создания заказа (без HTTP)."""

    def test_empty_cart_raises(self, user):
        with pytest.raises(OrderError, match='Корзина пуста'):
            create_order_from_cart(user)

    def test_success(self, user, product):
        CartItem.objects.create(user=user, product=product, quantity=2)

        order = create_order_from_cart(user)

        # Заказ создан
        assert order.status == 'paid'
        assert order.total == Decimal('1000.00')
        assert order.items.count() == 1

        # Цена зафиксирована
        item = order.items.first()
        assert item.price == Decimal('500.00')
        assert item.quantity == 2

        # Баланс списан
        user.refresh_from_db()
        assert user.balance == Decimal('0.00')   # было 1000, списали 1000

        # Склад уменьшен
        product.refresh_from_db()
        assert product.stock == 8

        # Корзина очищена
        assert not CartItem.objects.filter(user=user).exists()

    def test_insufficient_balance(self, user, product):
        # Баланс 1000, товар 500 x 3 = 1500
        CartItem.objects.create(user=user, product=product, quantity=3)

        with pytest.raises(OrderError, match='Недостаточно средств'):
            create_order_from_cart(user)

        # Ничего не изменилось
        user.refresh_from_db()
        product.refresh_from_db()
        assert user.balance == Decimal('1000.00')
        assert product.stock == 10
        assert CartItem.objects.filter(user=user).exists()
        assert Order.objects.count() == 0

    def test_insufficient_stock(self, user, product):
        # На складе 10, заказываем 20
        CartItem.objects.create(user=user, product=product, quantity=20)

        with pytest.raises(OrderError, match='недостаточно на складе'):
            create_order_from_cart(user)

        # Ничего не изменилось
        user.refresh_from_db()
        product.refresh_from_db()
        assert user.balance == Decimal('1000.00')
        assert product.stock == 10
        assert CartItem.objects.filter(user=user).exists()
        assert Order.objects.count() == 0

    def test_transaction_rollback_on_second_item_failure(self, user, product):
        """Если второй товар не проходит — первый тоже откатывается."""
        product2 = Product.objects.create(
            name='Ручка',
            price='100.00',
            stock=1,   # мало на складе
        )
        # Баланс 1000, Книга 500 x 1 + Ручка 100 x 5 = 1000 (хватает)
        # Но ручки только 1 на складе — должно упасть
        CartItem.objects.create(user=user, product=product, quantity=1)
        CartItem.objects.create(user=user, product=product2, quantity=5)

        with pytest.raises(OrderError):
            create_order_from_cart(user)

        # Ничего не изменилось
        user.refresh_from_db()
        product.refresh_from_db()
        product2.refresh_from_db()

        assert user.balance == Decimal('1000.00')
        assert product.stock == 10       # книга не тронута
        assert product2.stock == 1       # ручка не тронута
        assert Order.objects.count() == 0
        assert OrderItem.objects.count() == 0
        assert CartItem.objects.count() == 2
