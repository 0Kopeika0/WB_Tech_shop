import logging
from decimal import Decimal

from django.conf import settings
from django.core.mail import send_mail
from django.db import transaction

from apps.cart.models import CartItem
from apps.products.models import Product
from .exceptions import OrderError
from .models import Order, OrderItem


@transaction.atomic
def create_order_from_cart(user):
    """
    Создаёт заказ из корзины пользователя.
    ...
    """
    # 1. Получить корзину пользователя с товарами
    cart_items = CartItem.objects.filter(
        user=user,
    ).select_related('product')

    if not cart_items.exists():
        raise OrderError('Корзина пуста')

    # 2. Заблокировать товары от гонок и проверить остатки
    product_ids = [item.product_id for item in cart_items]
    locked_products = {
        p.id: p
        for p in Product.objects.select_for_update().filter(id__in=product_ids)
    }

    total = Decimal('0.00')

    for item in cart_items:
        product = locked_products[item.product_id]

        if product.stock < item.quantity:
            raise OrderError(
                f'Товара «{product.name}» недостаточно на складе. '
                f'Доступно: {product.stock}, запрошено: {item.quantity}'
            )

        total += product.price * item.quantity

    # 3. Проверить баланс
    if user.balance < total:
        raise OrderError(
            f'Недостаточно средств. '
            f'Нужно: {total}, на балансе: {user.balance}'
        )

    # 4. Создать заказ
    order = Order.objects.create(
        user=user,
        status='paid',
        total=total,
    )

    # 5. Создать позиции заказа и списать остатки
    for item in cart_items:
        product = locked_products[item.product_id]

        OrderItem.objects.create(
            order=order,
            product=product,
            quantity=item.quantity,
            price=product.price,
        )

        product.stock -= item.quantity
        product.save(update_fields=['stock'])

    # 6. Списать баланс
    user.balance -= total
    user.save(update_fields=['balance'])

    # 7. Очистить корзину
    cart_items.delete()

    # 8. Логирование
    logger = logging.getLogger(__name__)
    logger.info(
        'Заказ #%s создан пользователем %s на сумму %s',
        order.id, user.username, total,
    )

    # 9. Email-уведомление
    send_mail(
        subject=f'Заказ #{order.id} оформлен',
        message=(
            f'Здравствуйте, {user.username}!\n\n'
            f'Ваш заказ #{order.id} успешно оформлен.\n'
            f'Сумма: {total} руб.\n'
            f'Товаров: {len(cart_items)} позиций.\n\n'
            f'Спасибо за покупку!'
        ),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[user.email],
        fail_silently=False,
    )

    logger.info('Email-уведомление отправлено на %s', user.email)

    return order
