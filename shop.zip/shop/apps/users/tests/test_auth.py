import pytest
from django.urls import reverse

from apps.users.models import User


@pytest.mark.django_db
class TestRegistration:
    url = '/api/auth/register/'

    def test_register_success(self, api_client):
        response = api_client.post(self.url, {
            'username': 'newuser',
            'email': 'new@example.com',
            'password': 'secret12345',
            'password_confirm': 'secret12345',
        }, format='json')

        assert response.status_code == 201
        assert response.data['username'] == 'newuser'
        assert response.data['balance'] == '0.00'
        assert 'password' not in response.data
        assert User.objects.filter(username='newuser').exists()

    def test_register_password_mismatch(self, api_client):
        response = api_client.post(self.url, {
            'username': 'newuser',
            'email': 'new@example.com',
            'password': 'secret12345',
            'password_confirm': 'different',
        }, format='json')

        assert response.status_code == 400

    def test_register_duplicate_username(self, api_client, user):
        response = api_client.post(self.url, {
            'username': 'ivan',   # уже существует
            'email': 'other@example.com',
            'password': 'secret12345',
            'password_confirm': 'secret12345',
        }, format='json')

        assert response.status_code == 400
        assert 'username' in response.data


@pytest.mark.django_db
class TestLogin:
    url = '/api/auth/login/'

    def test_login_success(self, api_client, user):
        response = api_client.post(self.url, {
            'username': 'ivan',
            'password': 'secret12345',
        }, format='json')

        assert response.status_code == 200
        assert 'access' in response.data
        assert 'refresh' in response.data

    def test_login_wrong_password(self, api_client, user):
        response = api_client.post(self.url, {
            'username': 'ivan',
            'password': 'wrong',
        }, format='json')

        assert response.status_code == 401
