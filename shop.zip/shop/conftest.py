import pytest
from rest_framework.test import APIClient

from apps.users.models import User


@pytest.fixture
def api_client():
    """Обычный API-клиент без авторизации."""
    return APIClient()


@pytest.fixture
def user(db):
    """Обычный пользователь с балансом."""
    return User.objects.create_user(
        username='ivan',
        email='ivan@example.com',
        password='secret12345',
        balance=1000,
    )


@pytest.fixture
def admin_user(db):
    """Админ (is_staff=True)."""
    return User.objects.create_user(
        username='admin',
        email='admin@example.com',
        password='secret12345',
        is_staff=True,
        balance=10000,
    )


@pytest.fixture
def auth_client(api_client, user):
    """API-клиент, авторизованный под user (JWT)."""
    response = api_client.post(
        '/api/auth/login/',
        {'username': 'ivan', 'password': 'secret12345'},
        format='json',
    )
    token = response.data['access']
    api_client.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')
    return api_client


@pytest.fixture
def admin_client(api_client, admin_user):
    """API-клиент, авторизованный под admin."""
    response = api_client.post(
        '/api/auth/login/',
        {'username': 'admin', 'password': 'secret12345'},
        format='json',
    )
    token = response.data['access']
    api_client.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')
    return api_client
